﻿using System;
using System.Data;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace vcheck
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {       
            DataTable gvtable = versions();
            string[] entry = TextBox1.Text.Split('.');
            int entrylen = entry.Length;

            foreach (Software sw in SoftwareManager.GetAllSoftware())
            {
                try
                {
                    string Version = sw.Version+".";
                    string[] vparts = Version.Split('.');

                    bool later = false;
                    int act = 0;

                    while (act < 5 && later == false)
                    {
                        
                        int vpart = 0;
                        int entrynum = 0;

                        try { entrynum = Int32.Parse(entry[act]); } catch { }
                        try { vpart = Int32.Parse(vparts[act]); } catch { } 
                        if(vpart < entrynum)
                        {
                            act = 5;
                        }
                        if (entrynum < vpart)
                        {
                            later = true;
                        }
                        act++;
                    }
                    if (later == true)
                    { gvtable.Rows.Add(sw.Name, sw.Version); }
                }
                catch { }
            }

            GridView1.DataSource = gvtable;
            GridView1.DataBind();

        }
        public DataTable versions()
        {
            DataTable table = new DataTable();
            table.Columns.Add("Name", typeof(string));
            table.Columns.Add("Version", typeof(string));      

            return table;
        }

    }
    public class Software
    {
        public string Name { get; set; }
        public string Version { get; set; }
    }

    public static class SoftwareManager
    {
        public static IEnumerable<Software> GetAllSoftware()
        {
            return new List<Software>
        {
            new Software
            {
                Name = "MS Word",
                Version = "13.2.1"
            },
            new Software
            {
                Name = "AngularJS",
                Version = "1.7.1"
            },
            new Software
            {
                Name = "Angular",
                Version = "13"
            },
            new Software
            {
                Name = "React",
                Version = "0.0.5"
            },
            new Software
            {
                Name = "Vue.js",
                Version = "2.6"
            },
            new Software
            {
                Name = "Visual Studio",
                Version = "17.0.31919.166.0"
            },
            new Software
            {
                Name = "Visual Studio",
                Version = "16.11.9.3.55"
            },
            new Software
            {
                Name = "Visual Studio Code",
                Version = "1.63"
            },
            new Software
            {
                Name = "Blazor",
                Version = "3.2.0"
            }
        };
        }
    }
    

}